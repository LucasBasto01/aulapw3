<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Celke</title>
        
    </head>
    <body>

        <h1>Projeto Laravel</h1>

        <a href="<?php echo e(route('conta.index')); ?>">Listar as Contas</a>
        
    </body>
</html>
<?php /**PATH C:\wamp64\www\celke\resources\views/welcome.blade.php ENDPATH**/ ?>